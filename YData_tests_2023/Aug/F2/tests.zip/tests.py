import numpy as np
import os
import pandas as pd

def get_data():
    data_path = os.path.dirname(__file__)
    users_file = os.path.join(data_path,'users_data.csv')
    calls_file = os.path.join(data_path,'calls_data.csv')
    msg_file = os.path.join(data_path,'msg_data.csv')
    web_file = os.path.join(data_path,'web_data.csv')
    users_data = pd.read_csv(users_file)
    calls_data = pd.read_csv(calls_file)
    msg_data = pd.read_csv(msg_file)
    web_data = pd.read_csv(web_file)
    q = []
    a = []
    for i in range(10):
        input_file = os.path.join(data_path,'{:02}'.format(i+1))
        output_file = os.path.join(data_path,'{:02}'.format(i+1)+'.a')
        with open(input_file) as f:
            data_in = f.read().splitlines()
        f.close()
        with open(output_file) as f:
            data_out = f.read().splitlines()
        f.close()
        q.append(int(data_in[0]))
        a.append(float(data_out[0]))
    return users_data, calls_data, msg_data, web_data, q, a