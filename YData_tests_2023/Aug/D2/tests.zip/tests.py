import numpy as np
import os


def get_data():
    data_path = os.path.dirname(__file__)
    q = []
    a = []
    for i in range(20):
        input_file = os.path.join(data_path,'{:02}'.format(i+1))
        output_file = os.path.join(data_path,'{:02}'.format(i+1)+'.a')
        with open(input_file) as f:
            data_in = f.read().splitlines()
        f.close()
        with open(output_file) as f:
            data_out = f.read().splitlines()
        f.close()
        q.append(data_in[0])
        a.append(int(data_out[0]))
    return q,a