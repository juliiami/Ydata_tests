import numpy as np
import os
import pandas as pd


def get_data():
    data_path = os.path.dirname(__file__)
    input_file = os.path.join(data_path,'calls_data.csv')
    df = pd.read_csv(input_file)
    q = []
    a = []
    for i in range(10):
        input_file = os.path.join(data_path,'{:02}'.format(i+1))
        output_file = os.path.join(data_path,'{:02}'.format(i+1)+'.a')
        with open(input_file) as f:
            data_in = f.read().splitlines()
        f.close()
        with open(output_file) as f:
            data_out = f.read().splitlines()
        f.close()
        q.append([int(i) for i in data_in])
        a.append(int(data_out[0]))
    return df, q, a