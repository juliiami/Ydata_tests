import numpy as np
import os
import pandas as pd


def get_data():
    data_path = os.path.dirname(__file__)
    input_file = os.path.join(data_path,'E1_result.csv')
    df = pd.read_csv(input_file)
    q = []
    a = []
    for i in range(12):
        input_file = os.path.join(data_path,'{:02}'.format(i+1))
        output_file = os.path.join(data_path,'{:02}'.format(i+1)+'.a')
        with open(input_file) as f:
            data_in = f.read().splitlines()
        f.close()
        with open(output_file) as f:
            data_out = f.read().splitlines()
        f.close()
        q.append(data_in)
        a.append(data_out[0])
    return df, q, a