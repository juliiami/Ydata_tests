import numpy as np
import os
import pandas as pd

def get_data():
    data_path = os.path.dirname(__file__)
    stream_file = os.path.join(data_path,'stream_data.csv')
    stream_data = pd.read_csv(stream_file)
    q = []
    a = []
    for i in range(10):
        input_file = os.path.join(data_path,'{:02}'.format(i+1))
        output_file = os.path.join(data_path,'{:02}'.format(i+1)+'.a')
        with open(input_file) as f:
            data_in = f.read().splitlines()
        f.close()
        with open(output_file) as f:
            data_out = f.read().splitlines()
        f.close()
        q.append(data_in[0].split())
        a.append(int(data_out[0]))
    return stream_data, q, a