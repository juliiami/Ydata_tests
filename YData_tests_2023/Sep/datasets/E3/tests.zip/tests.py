import numpy as np
import os
import pandas as pd

def get_data():
    data_path = os.path.dirname(__file__)
    input_file = os.path.join(data_path,'countries.csv')
    data = pd.read_csv(input_file)
    q = []
    a = []
    for i in [*range(3), *range(5, 14)]:
        input_file = os.path.join(data_path,'{:02}'.format(i+1))
        output_file = os.path.join(data_path,'{:02}'.format(i+1)+'.a')
        with open(input_file) as f:
            data_in = f.read().splitlines()
        f.close()
        with open(output_file) as f:
            data_out = f.read().splitlines()
        f.close()
        arr = data_in[0].split(', ')
        inp = [arr[0].split("'")[1]]
        for i in arr[1:]:
            inp.append(float(i))
        q.append(inp)
        a.append(data_out[0])
    return data,q,a
    