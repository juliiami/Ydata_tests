import numpy as np
import os


def get_data():
    data_path = os.path.dirname(__file__)
    x = []
    A = []
    B = []
    o = []
    for i in range(33):
        input_file = os.path.join(data_path,'{:02}'.format(i+1))
        output_file = os.path.join(data_path,'{:02}'.format(i+1)+'.a')
        with open(input_file) as f:
            data_in = f.read().splitlines()
        f.close()
        with open(output_file) as f:
            data_out = f.read().splitlines()
        f.close()
        x.append(int(data_in[0]))
        A.append(data_in[1])
        B.append(data_in[2])
        o.append(int(data_out[0]))
    return x, A, B, o