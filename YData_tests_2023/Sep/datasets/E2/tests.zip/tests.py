import numpy as np
import os
import pandas as pd

def get_data():
    data_path = os.path.dirname(__file__)
    input_file = os.path.join(data_path,'countries.csv')
    output_file = os.path.join(data_path,'01.a')
    with open(output_file) as f:
        data_out = f.read().splitlines()
    f.close()
    data_in = pd.read_csv(input_file)
    return data_in, data_out