import os

import pandas as pd


def get_data():
    data_path = os.path.dirname(__file__)
    input_file = os.path.join(data_path, "apple_quality.csv")
    output_file_v1 = os.path.join(data_path, "best_apples_v1.csv")
    output_file_v2 = os.path.join(data_path, "best_apples_v2.csv")
    data_in = pd.read_csv(input_file)
    data_out_1 = pd.read_csv(output_file_v1, squeeze=True).to_list()
    data_out_2 = pd.read_csv(output_file_v2, squeeze=True).to_list()
    return data_in, data_out_1, data_out_2
